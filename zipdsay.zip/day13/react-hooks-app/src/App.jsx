import React from 'react';
import ImageApp from './Components/imaageapp'; 
import{browserRouter,routes,Rote}from "react-route-dom";
import MainLayout from "./Components/MainLayout";

const App = () => {

return(
  <div>
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<MainLayout/>}>
      <Route path="/Counterapp" element={<CounterApp/>}>
      <Route path="/imageapp" element={<imaa/>}>


      </Route>
      </Routes></BrowserRouter>
  </div>
)
export default App;
